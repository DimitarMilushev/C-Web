﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIS.HTTP.Enums
{
    public enum HttpRequestMethod
    {
        Get,
        Post,
        Put,
        Delete
    }
}